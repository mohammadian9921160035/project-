import React, {useState} from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './App.css';
import Cart from './components/basket/Cart';
import Products from './components/product/Products';
import Navbar from './components/Navbar';
import { Context } from "./components/Context";

const App =() =>{
  const [darkMode, setDarkMode] = useState(false);
 
  return (

    <BrowserRouter>
       <Context>  
         <div className={darkMode ? 'dark-mode' : 'light-mode'}>
              <Navbar />
            <div className='switch-button'>
                <button  onClick={() => setDarkMode(!darkMode)}>
                  DarkMode
                </button>
            </div>
              <Routes>
              <Route index element={<Products/>} />
              <Route path="/Cart" element={< Cart/>} />
              </Routes>
         </div>
      </Context>
    </BrowserRouter>
    
  );
}

export default App;
