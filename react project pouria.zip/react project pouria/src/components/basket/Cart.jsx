
import React from "react";
import { useContext } from "react";
import { Cartcontext } from "../Context";
import "./Basket.css";
import '../DATA/data.json'

const Cart = () => {
  const Globalstate = useContext(Cartcontext);
  const state = Globalstate.state;
  const dispatch = Globalstate.dispatch;

  const total = state.reduce((total, item) => {
    return total + item.price * item.quantity;
  }, 0);
  return (
    <div className="cart">
      
         <p className="emptybasket" >
        {state.length===0  ? <div> سبد شما خالی است</div>  :  ""}
        </p>
        
      {state.map((item, index) => {
        return (
          <div className="card" key={index}>
            <img src={item.imgUrl} alt="" />
            <p>{item.name}</p>
            <p>{item.quantity * item.price+"     $"}</p>
            <div className="quantity">
              <button
                onClick={() => dispatch({ type: "INCREASE", payload: item })}>
                +
              </button>
              <p>{item.quantity}</p>
              <button
                onClick={() => {
                  if (item.quantity > 1) {
                    dispatch({ type: "DECREASE", payload: item });
                  } else {
                    dispatch({ type: "REMOVE", payload: item });
                  }
                }}>
                -
              </button>
            </div>
            <button className="exbutton" onClick={() => dispatch({ type: "REMOVE", payload: item })}>
              REMOVE
            </button>
          </div>
        );
      })}
      {state.length > 0 && (
        <div className="total">
          <p>Total Amount</p>
          <h2>{total+"     $"}</h2>
        </div>
      )}
    
    </div>
  );
};

export default Cart;