import React from 'react';
import './product.css';
import { useContext} from "react";
import { Cartcontext } from "../Context";
// import { Link } from 'react-router-dom'

const Productitem = ({ item }) => {
  const Globalstate = useContext(Cartcontext);
  const dispatch = Globalstate.dispatch;
   return (

    <div className='Productcontainer'>
      <div className='img-container'>
      <img src={item.imgUrl} alt={item.name}/>
      </div>
      <div className='Productcontainer-footer'>
        <h3>{item.name}</h3>
        <h4 className='itemprice'>{item.price+"     $"}</h4>
  
        <p>{item.desc}</p>
       
          <button className="buyitem"  onClick={() => dispatch({ type: "ADD", payload: item })
        }>
            BUY
      </button>


        </div>
    </div>

    );
  }
  
export default Productitem;
