import Productitem from './Productitem';
import React, { useState, useEffect } from "react";
import storeItems from "../DATA/data.json"
import './product.css';

const Products = () => {
  const [searchValue, setsearchValue] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  
  const handleChange = (event) => {
    setsearchValue(event.target.value);
  };

  useEffect(() => {
    const results = storeItems.filter((item ) =>{
      return item.name.toLowerCase().includes(searchValue.toLowerCase()) || item.desc.toLowerCase().includes(searchValue.toLowerCase())
    }
      );
    setSearchResults(results);
  }, [searchValue]);


  const filterItems = (category) => {
    if (category === 'ALL') {
      setSearchResults(storeItems);
      return;
    }
    const newItems = storeItems.filter((item) => item.categories === category);
    setSearchResults(newItems);
  };


  const sortLHPrice = () => {
    const newItemssort =storeItems.sort((a, b) => a.price - b.price).filter((item) => item);

    setSearchResults(newItemssort);
  };
  const sortHLPrice = () => {

    setSearchResults(storeItems.sort((a, b) => b.price - a.price));
  
  };



   return (
     <div>

      <form className='search-form' onSubmit>
              <input
        type="text"
        placeholder="جست و جو..."
        value={searchValue}
        onChange={handleChange}/>
      </form>


    
      <div className="filter-btns">

       <button className="filter-btn"
            onClick={() => filterItems("ALL")}>
            کل محصولات
      </button>
      <button
            className="filter-btn"
            onClick={() => filterItems("JACKETS")}
          >
            جکت ها
       </button>
       <button

            className="filter-btn"
            onClick={() => filterItems("SHOES")}
          >
            کفش ها
       </button>
      <button className="filter-btn"
            onClick={() => filterItems("JEANS")}>
             جین 
      </button>
     
   

      <button className="sortbutton"
            onClick={sortLHPrice}>
            sortprice(low-high)
      </button>

      <button className="sortbutton"
            onClick={sortHLPrice}>
       sortprice(high-low)
      </button>
         

      </div>
      <br />
        <br /> <br />
     <div className="Productcontainer-center ">
       
      {searchResults.map((item) => (
        <Productitem  item={item} key={item.id} />
        
        ))}

      </div>
      </div>
    );
  }
  
export default Products;
